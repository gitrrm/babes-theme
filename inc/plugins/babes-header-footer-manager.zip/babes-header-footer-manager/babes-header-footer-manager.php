<?php
/**
 * Plugin Name: Babes Header Footer Manager
 * Description: A plugin to manage header and footer templates using Elementor.
 * Version: 1.0
 * Author: triloke authors
 * Text Domain: babes-header-footer-manager
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define plugin path
define('BHF_PLUGIN_PATH', plugin_dir_path(__FILE__));

// Include necessary files
require_once BHF_PLUGIN_PATH . 'includes/class-bhf-header-footer.php';
require_once BHF_PLUGIN_PATH . 'includes/class-bhf-admin.php';

// Initialize the plugin
function bhf_initialize_plugin() {
    $header_footer = new BHF_Header_Footer();
    $header_footer->init();
    
    $admin = new BHF_Admin();
    $admin->init();
}
add_action('plugins_loaded', 'bhf_initialize_plugin');
