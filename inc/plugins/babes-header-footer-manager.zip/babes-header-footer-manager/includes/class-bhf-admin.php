<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class BHF_Admin {

    public function init() {
        add_action('init', array($this, 'register_custom_post_type'));
        add_action('add_meta_boxes', array($this, 'add_meta_box'));
        add_action('save_post', array($this, 'save_meta_box_data'));
        add_action('wp_insert_post', array($this, 'set_default_elementor_template'), 10, 3);
        add_filter('manage_bhf_template_posts_columns', array($this, 'add_custom_columns'));
        add_action('manage_bhf_template_posts_custom_column', array($this, 'render_custom_columns'), 10, 2);
    }


    public function register_custom_post_type() {
        $labels = array(
            'name'                  => _x('Header & Footer Templates', 'Post type general name', 'textdomain'),
            'singular_name'         => _x('Header & Footer Template', 'Post type singular name', 'textdomain'),
            'menu_name'             => _x('Header & Footer Templates', 'Admin Menu text', 'textdomain'),
            'name_admin_bar'        => _x('Header & Footer Template', 'Add New on Toolbar', 'textdomain'),
            'add_new'               => __('Add New', 'textdomain'),
            'add_new_item'          => __('Add New Template', 'textdomain'),
            'new_item'              => __('New Template', 'textdomain'),
            'edit_item'             => __('Edit Template', 'textdomain'),
            'view_item'             => __('View Template', 'textdomain'),
            'all_items'             => __('All Templates', 'textdomain'),
            'search_items'          => __('Search Templates', 'textdomain'),
            'parent_item_colon'     => __('Parent Templates:', 'textdomain'),
            'not_found'             => __('No templates found.', 'textdomain'),
            'not_found_in_trash'    => __('No templates found in Trash.', 'textdomain'),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => 'header-footer-template'),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 20,
            'supports'           => array('title', 'editor', 'elementor'),
        );

        register_post_type('bhf_template', $args);
    }

    public function add_meta_box() {
        add_meta_box(
            'bhf_template_meta_box',
            'Template Type',
            array($this, 'meta_box_callback'),
            'bhf_template',
            'side',
            'default'
        );
    }

    public function meta_box_callback($post) {
        // Meta box fields
        include BHF_PLUGIN_PATH . 'includes/meta-box.php'; // Include the meta box HTML and JS
    }

    public function save_meta_box_data($post_id) {
        // Save meta box data
        include BHF_PLUGIN_PATH . 'includes/save-meta-box.php'; // Include the meta box save functionality
    }

    /*public function set_default_elementor_template($post_id, $post, $update) {
	    // Only run for new posts of the custom post type
	    if ($post->post_type === 'bhf_template' && !$update) {
	        // Check if Elementor's Canvas template is applied
	        if (!get_post_meta($post_id, '_elementor_template_type', true)) {
	            // Apply the Elementor Canvas template
	            update_post_meta($post_id, '_elementor_template_type', 'canvas');
	        }
	    }
	}*/

	public function set_default_elementor_template($post_id, $post, $update) {
	    // Only run for new posts of the custom post type
	    if ($post->post_type === 'bhf_template' && !$update) {
	        // Ensure Elementor is active
	        if (class_exists('Elementor\Plugin')) {
	            $elementor = \Elementor\Plugin::instance();

	            // Ensure the Elementor Canvas template is set
	            $default_template_id = $this->get_canvas_template_id();

	            echo $default_template_id;

	            if ($default_template_id) {
	                // Load Elementor Document
	                $document = $elementor->documents->get($post_id);
	                
	                if ($document) {
	                    // Update the page layout to Elementor Canvas
	                    $document->update_settings([
	                        'page_template' => 'elementor_canvas'

	                    ]);

	                    // Save the changes
	                    $document->save();
	                }
	            }
	        }
	    }
	}

	private function get_canvas_template_id() {
	    // Get the default Elementor Canvas template ID
	    $canvas_template = get_page_by_path('elementor-canvas-template', OBJECT, 'elementor_library');
	    return $canvas_template ? $canvas_template->ID : false;
	}


    public function add_custom_columns($columns) {
        // Add a new column for Template Type and preserve the default columns
        $new_columns = array(
            'cb' => $columns['cb'], // Ensure checkbox column is included
            'title' => __('Title', 'textdomain'),
            'template_type' => __('Template Type', 'textdomain'),
            'date' => __('Date', 'textdomain')
        );

        return $new_columns;
    }

    public function render_custom_columns($column, $post_id) {
        if ($column === 'template_type') {
            $template_type = get_post_meta($post_id, '_bhf_template_type', true);
            echo esc_html($template_type ? ucfirst($template_type) : __('N/A', 'textdomain'));
        }
    }

    
}
