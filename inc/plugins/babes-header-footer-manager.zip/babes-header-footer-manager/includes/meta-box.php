<p>
    <label for="bhf_template_type">Template Type:</label>
    <select name="bhf_template_type" id="bhf_template_type">
        <option value="header" <?php selected($template_type, 'header'); ?>>Header</option>
        <option value="footer" <?php selected($template_type, 'footer'); ?>>Footer</option>
    </select>
</p>

<p>
    <label for="bhf_apply_to">Apply To:</label>
    <select name="bhf_apply_to" id="bhf_apply_to">
        <option value="entire_website" <?php selected($apply_to, 'entire_website'); ?>>Entire Website</option>
        <option value="specific_pages_posts" <?php selected($apply_to, 'specific_pages_posts'); ?>>Specific Pages/Posts</option>
    </select>
</p>

<div id="bhf_specific_pages_posts" style="display: <?php echo $apply_to === 'specific_pages_posts' ? 'block' : 'none'; ?>;">
    <p>
        <label for="bhf_selected_pages">Select Pages:</label>
        <select name="bhf_selected_pages[]" id="bhf_selected_pages" multiple>
            <?php foreach ($pages as $page): ?>
                <option value="<?php echo esc_attr($page->ID); ?>" <?php echo in_array($page->ID, (array)$selected_pages) ? 'selected' : ''; ?>>
                    <?php echo esc_html($page->post_title); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </p>
    <p>
        <label for="bhf_selected_posts">Select Posts:</label>
        <select name="bhf_selected_posts[]" id="bhf_selected_posts" multiple>
            <?php foreach ($posts as $post): ?>
                <option value="<?php echo esc_attr($post->ID); ?>" <?php echo in_array($post->ID, (array)$selected_posts) ? 'selected' : ''; ?>>
                    <?php echo esc_html($post->post_title); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </p>
</div>

<script type="text/javascript">
jQuery(document).ready(function($) {
    $('#bhf_apply_to').change(function() {
        if ($(this).val() === 'specific_pages_posts') {
            $('#bhf_specific_pages_posts').show();
        } else {
            $('#bhf_specific_pages_posts').hide();
        }
    }).trigger('change');
});
</script>
