<?php
if (array_key_exists('bhf_template_type', $_POST)) {
    update_post_meta($post_id, '_bhf_template_type', sanitize_text_field($_POST['bhf_template_type']));
}

if (array_key_exists('bhf_apply_to', $_POST)) {
    update_post_meta($post_id, '_bhf_apply_to', sanitize_text_field($_POST['bhf_apply_to']));
}

if (array_key_exists('bhf_selected_pages', $_POST)) {
    update_post_meta($post_id, '_bhf_selected_pages', array_map('intval', $_POST['bhf_selected_pages']));
}

if (array_key_exists('bhf_selected_posts', $_POST)) {
    update_post_meta($post_id, '_bhf_selected_posts', array_map('intval', $_POST['bhf_selected_posts']));
}
