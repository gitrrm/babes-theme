<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class BH_Elementor_Manager {
    public function __construct() {
        add_action('elementor/widgets/widgets_registered', [$this, 'register_widgets']);
        add_action('elementor/widgets/widgets_registered', [$this, 'register_bhf_widgets']);
    }

    public function register_widgets() {
        // Register widgets to handle header and footer templates.
    }
    function register_bhf_widgets() {
	    // Register header and footer widgets here
	}
}


