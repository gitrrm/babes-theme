<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Register Custom Post Type
function bhf_register_custom_post_type() {
    $labels = array(
        'name'                  => _x('Header & Footer Templates', 'Post type general name', 'textdomain'),
        'singular_name'         => _x('Header & Footer Template', 'Post type singular name', 'textdomain'),
        'menu_name'             => _x('Header & Footer Templates', 'Admin Menu text', 'textdomain'),
        'name_admin_bar'        => _x('Header & Footer Template', 'Add New on Toolbar', 'textdomain'),
        'add_new'               => __('Add New', 'textdomain'),
        'add_new_item'          => __('Add New Template', 'textdomain'),
        'new_item'              => __('New Template', 'textdomain'),
        'edit_item'             => __('Edit Template', 'textdomain'),
        'view_item'             => __('View Template', 'textdomain'),
        'all_items'             => __('All Templates', 'textdomain'),
        'search_items'          => __('Search Templates', 'textdomain'),
        'parent_item_colon'     => __('Parent Templates:', 'textdomain'),
        'not_found'             => __('No templates found.', 'textdomain'),
        'not_found_in_trash'    => __('No templates found in Trash.', 'textdomain'),
        'featured_image'        => _x('Template Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'textdomain'),
        'set_featured_image'    => _x('Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'textdomain'),
        'remove_featured_image' => _x('Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'textdomain'),
        'use_featured_image'    => _x('Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'textdomain'),
        'archives'              => _x('Template archives', 'The post type archive label used in nav menus. Defaults to the post type name. Added in 4.4', 'textdomain'),
        'insert_into_item'      => _x('Insert into template', 'Overrides the “Insert into post” phrase for this post type. Added in 4.4', 'textdomain'),
        'uploaded_to_this_item' => _x('Uploaded to this template', 'Overrides the “Uploaded to this post” phrase for this post type. Added in 4.4', 'textdomain'),
        'filter_items_list'     => _x('Filter templates list', 'Screen reader text for the filter links heading', 'textdomain'),
        'items_list_navigation' => _x('Templates list navigation', 'Screen reader text for the pagination heading', 'textdomain'),
        'items_list'            => _x('Templates list', 'Screen reader text for the items list heading', 'textdomain'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'header-footer-template'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array('title', 'elementor', 'thumbnail'),
    );

    register_post_type('bhf_template', $args);
}
add_action('init', 'bhf_register_custom_post_type');

// Add Meta Box
function bhf_add_meta_box() {
    add_meta_box(
        'bhf_template_meta_box',
        'Template Type',
        'bhf_meta_box_callback',
        'bhf_template',
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'bhf_add_meta_box');

/*function bhf_meta_box_callback($post) {
    $selected_value = get_post_meta($post->ID, '_bhf_template_type', true);
    ?>
    <label for="bhf_template_type">
        <select name="bhf_template_type" id="bhf_template_type">
            <option value="header" <?php selected($selected_value, 'header'); ?>>Header</option>
            <option value="footer" <?php selected($selected_value, 'footer'); ?>>Footer</option>
        </select>
    </label>
    <?php
}*/
function bhf_meta_box_callback($post) {
    $template_type = get_post_meta($post->ID, '_bhf_template_type', true);
    $apply_to = get_post_meta($post->ID, '_bhf_apply_to', true);
    $selected_pages = get_post_meta($post->ID, '_bhf_selected_pages', true);
    $selected_posts = get_post_meta($post->ID, '_bhf_selected_posts', true);

    // Get all pages and posts for dropdowns
    $pages = get_pages();
    $posts = get_posts(['post_type' => 'post', 'numberposts' => -1]);

    ?>
    <p>
        <label for="bhf_template_type">Template Type:</label>
        <select name="bhf_template_type" id="bhf_template_type">
            <option value="header" <?php selected($template_type, 'header'); ?>>Header</option>
            <option value="footer" <?php selected($template_type, 'footer'); ?>>Footer</option>
        </select>
    </p>
    
    <p>
        <label for="bhf_apply_to">Apply To:</label>
        <select name="bhf_apply_to" id="bhf_apply_to">
            <option value="entire_website" <?php selected($apply_to, 'entire_website'); ?>>Entire Website</option>
            <option value="specific_pages_posts" <?php selected($apply_to, 'specific_pages_posts'); ?>>Specific Pages/Posts</option>
        </select>
    </p>

    <div id="bhf_specific_pages_posts" style="display: <?php echo $apply_to === 'specific_pages_posts' ? 'block' : 'none'; ?>;">
        <p>
            <label for="bhf_selected_pages">Select Pages:</label>
            <select name="bhf_selected_pages[]" id="bhf_selected_pages" multiple>
                <?php foreach ($pages as $page): ?>
                    <option value="<?php echo esc_attr($page->ID); ?>" <?php echo in_array($page->ID, (array)$selected_pages) ? 'selected' : ''; ?>>
                        <?php echo esc_html($page->post_title); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        <p>
            <label for="bhf_selected_posts">Select Posts:</label>
            <select name="bhf_selected_posts[]" id="bhf_selected_posts" multiple>
                <?php foreach ($posts as $post): ?>
                    <option value="<?php echo esc_attr($post->ID); ?>" <?php echo in_array($post->ID, (array)$selected_posts) ? 'selected' : ''; ?>>
                        <?php echo esc_html($post->post_title); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
    </div>

    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('#bhf_apply_to').change(function() {
            if ($(this).val() === 'specific_pages_posts') {
                $('#bhf_specific_pages_posts').show();
            } else {
                $('#bhf_specific_pages_posts').hide();
            }
        }).trigger('change');
    });
    </script>
    <?php
}

function bhf_save_meta_box_data($post_id) {
    if (array_key_exists('bhf_template_type', $_POST)) {
        update_post_meta($post_id, '_bhf_template_type', sanitize_text_field($_POST['bhf_template_type']));
    }

    if (array_key_exists('bhf_apply_to', $_POST)) {
        update_post_meta($post_id, '_bhf_apply_to', sanitize_text_field($_POST['bhf_apply_to']));
    }

    if (array_key_exists('bhf_selected_pages', $_POST)) {
        update_post_meta($post_id, '_bhf_selected_pages', array_map('intval', $_POST['bhf_selected_pages']));
    }

    if (array_key_exists('bhf_selected_posts', $_POST)) {
        update_post_meta($post_id, '_bhf_selected_posts', array_map('intval', $_POST['bhf_selected_posts']));
    }
}
add_action('save_post', 'bhf_save_meta_box_data');

/*function bhf_save_meta_box_data($post_id) {
    if (array_key_exists('bhf_template_type', $_POST)) {
        update_post_meta(
            $post_id,
            '_bhf_template_type',
            sanitize_text_field($_POST['bhf_template_type'])
        );
    }
}
add_action('save_post', 'bhf_save_meta_box_data');*/

// Set Elementor Canvas Template by default
function bhf_set_default_template($post_id) {
    if (get_post_type($post_id) !== 'bhf_template') {
        return;
    }

    // Check if Elementor Canvas template is set
    $template_meta_key = '_elementor_template_type';
    $current_template = get_post_meta($post_id, $template_meta_key, true);

    if (empty($current_template)) {
        // Set Elementor Canvas template
        update_post_meta($post_id, $template_meta_key, 'elementor_canvas');
    }
}
add_action('save_post', 'bhf_set_default_template');

function bhf_apply_header_footer_template() {
    if (is_singular()) {
        global $post;

        $templates = get_posts(array(
            'post_type'   => 'bhf_template',
            'meta_query'  => array(
                array(
                    'key'   => '_bhf_template_type',
                    'value' => 'header', // Change to 'footer' for footer
                ),
                array(
                    'key'     => '_bhf_apply_to',
                    'value'   => 'specific_pages_posts',
                    'compare' => 'LIKE'
                ),
                array(
                    'key'     => '_bhf_selected_pages',
                    'value'   => $post->ID,
                    'compare' => 'IN',
                ),
                array(
                    'key'     => '_bhf_selected_posts',
                    'value'   => $post->ID,
                    'compare' => 'IN',
                ),
            ),
        ));

        if ($templates) {
            foreach ($templates as $template) {
                // Render the template
                echo apply_filters('the_content', $template->post_content);
            }
        }
    }
}
add_action('wp_head', 'bhf_apply_header_footer_template'); // Adjust hook based on placement

