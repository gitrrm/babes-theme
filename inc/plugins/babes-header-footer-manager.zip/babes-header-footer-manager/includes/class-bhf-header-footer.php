<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class BHF_Header_Footer {

    public function init() {
        add_action('wp_head', array($this, 'apply_header_footer_template'));
        // Add more hooks if needed
    }

    public function apply_header_footer_template() {
        if (is_singular()) {
            global $post;

            $templates = get_posts(array(
                'post_type'   => 'bhf_template',
                'meta_query'  => array(
                    array(
                        'key'   => '_bhf_template_type',
                        'value' => 'header', // Change to 'footer' for footer
                    ),
                    array(
                        'key'     => '_bhf_apply_to',
                        'value'   => 'specific_pages_posts',
                        'compare' => 'LIKE'
                    ),
                    array(
                        'key'     => '_bhf_selected_pages',
                        'value'   => $post->ID,
                        'compare' => 'IN',
                    ),
                    array(
                        'key'     => '_bhf_selected_posts',
                        'value'   => $post->ID,
                        'compare' => 'IN',
                    ),
                ),
            ));

            if ($templates) {
                foreach ($templates as $template) {
                    // Render the template
                    echo apply_filters('the_content', $template->post_content);
                }
            }
        }
    }
}
